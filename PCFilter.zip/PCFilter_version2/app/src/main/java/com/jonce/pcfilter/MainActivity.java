package com.jonce.pcfilter;


import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;
import com.google.common.util.concurrent.SettableFuture;
import com.jonce.pcfilter.adapter.SoftWareAdapter;
import com.jonce.pcfilter.modal.SoftWare;
import java.util.List;


//mobile service below
import java.net.MalformedURLException;
import android.os.AsyncTask;
import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.ListenableFuture;
import com.microsoft.windowsazure.mobileservices.MobileServiceClient;
import com.microsoft.windowsazure.mobileservices.MobileServiceList;
import com.microsoft.windowsazure.mobileservices.http.NextServiceFilterCallback;
import com.microsoft.windowsazure.mobileservices.http.ServiceFilter;
import com.microsoft.windowsazure.mobileservices.http.ServiceFilterRequest;
import com.microsoft.windowsazure.mobileservices.http.ServiceFilterResponse;
import com.microsoft.windowsazure.mobileservices.table.MobileServiceTable;
import com.microsoft.windowsazure.mobileservices.table.TableOperationCallback;
import com.microsoft.windowsazure.mobileservices.table.TableQueryCallback;


public class MainActivity extends AppCompatActivity
{

    private Button searchBtn;
    private ListView softwareLv;
    private ProgressBar mProgressBar;
    public static MobileServiceClient mClient;
    public static MobileServiceTable<ToDoItem> mToDoTable;
    SoftWareAdapter softWareAdapter;
    public static String text;
    ProgressDialog progress;

    public int[] img = {R.drawable.visualstudio, R.drawable.androidstudio, R.drawable.google,
            R.drawable.notepad, R.drawable.ie, R.drawable.eclipse};


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        searchBtn = (Button) findViewById(R.id.searchBtn);
        softwareLv = (ListView) findViewById(R.id.softwareLv);
        SoftWareAdapter.data.clear();
        progress=new ProgressDialog(this);
        progress.setTitle("Connecting");
        progress.setMessage("Retrieving data from server, please wait");

        try {
            // Create the Mobile Service Client instance, using the provided
            // Mobile Service URL and key
            mClient = new MobileServiceClient(
                    "https://gong.azure-mobile.net/",
                    "YxRfRBIYoKcUPcElHiCwRrXZQcJkRW89", this)
                    .withFilter(new ProgressFilter());

            mToDoTable = mClient.getTable(ToDoItem.class);

        } catch (MalformedURLException e) {
            createAndShowDialog(new Exception("Error creating the Mobile Service. " +
                    "Verify the URL"), "Error");
        }

        MainActivity.mToDoTable.where().field("complete").eq(false).execute(new TableQueryCallback<ToDoItem>() {
            @Override
            public void onCompleted(List<ToDoItem> result, int count, Exception exception, ServiceFilterResponse response) {
                if (result != null) {

                    SoftWare soft = new SoftWare(img[0], result.get(5).getText(), Integer.parseInt(result.get(5).getmCPU()), 3650, 4);
                    //Log.d("Fg", result.get(0).getmCPU());
                    SoftWareAdapter.data.add(soft);

                    SoftWare soft1 = new SoftWare(img[1], result.get(4).getText(), Integer.parseInt(result.get(4).getmCPU()), Integer.parseInt(result.get(4).getmGPU()), Integer.parseInt(result.get(4).getStrogae()));
                    SoftWareAdapter.data.add(soft1);

                    SoftWare soft2 = new SoftWare(img[2], result.get(0).getText(), Integer.parseInt(result.get(0).getmCPU()), Integer.parseInt(result.get(0).getmGPU()), Integer.parseInt(result.get(0).getStrogae()));
                    SoftWareAdapter.data.add(soft2);

                    SoftWare soft3 = new SoftWare(img[3], result.get(1).getText(), Integer.parseInt(result.get(1).getmCPU()), Integer.parseInt(result.get(1).getmGPU()), Integer.parseInt(result.get(1).getStrogae()));
                    SoftWareAdapter.data.add(soft3);

                    SoftWare soft4 = new SoftWare(img[4], result.get(3).getText(), Integer.parseInt(result.get(3).getmCPU()), Integer.parseInt(result.get(3).getmGPU()), Integer.parseInt(result.get(3).getStrogae()));
                    SoftWareAdapter.data.add(soft4);

                    SoftWare soft5 = new SoftWare(img[5], result.get(2).getText(), Integer.parseInt(result.get(2).getmCPU()), Integer.parseInt(result.get(2).getmGPU()), Integer.parseInt(result.get(2).getStrogae()));
                    SoftWareAdapter.data.add(soft5);


                    softWareAdapter = new SoftWareAdapter(MainActivity.this, SoftWareAdapter.data);
                    softwareLv.setAdapter(softWareAdapter);
                    softWareAdapter.notifyDataSetChanged();
                } else {
                    Log.d("Fg", "sb");
                }
            }
        });



        searchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ResultActivity.class);
                String selected = "";
                for (int i = 0; i < SoftWareAdapter.isSelected.size(); i++) {
                    if (SoftWareAdapter.isSelected.get(i)) {
                        selected += i + ",";
                    }
                }
                if (selected.equals("")) {
                    Toast.makeText(MainActivity.this, "Please select at least a software!", Toast.LENGTH_SHORT).show();
                } else {
                    intent.putExtra("selected", selected);
                    startActivity(intent);
                }
            }
        });


    }



    @Override

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    private void createAndShowDialog(Exception exception, String title) {
        createAndShowDialog(exception.toString(), title);
    }

    /**
     * Creates a dialog and shows it
     *
     * @param message
     *            The dialog message
     * @param title
     *            The dialog title
     */
    private void createAndShowDialog(String message, String title) {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);

        builder.setMessage(message);
        builder.setTitle(title);
        builder.create().show();
    }


    private class ProgressFilter implements ServiceFilter {
        @Override
        public ListenableFuture<ServiceFilterResponse> handleRequest(ServiceFilterRequest request, NextServiceFilterCallback nextServiceFilterCallback) {

            final SettableFuture<ServiceFilterResponse> resultFuture = SettableFuture.create();

            runOnUiThread(new Runnable() {

                @Override
                public void run() {
                    if (progress!=null)
                        progress.show();
                        progress.setCanceledOnTouchOutside(false);
                }
            });

            ListenableFuture<ServiceFilterResponse> future = nextServiceFilterCallback.onNext(request);

            Futures.addCallback(future, new FutureCallback<ServiceFilterResponse>() {
                @Override
                public void onFailure(Throwable e) {
                    resultFuture.setException(e);
                }

                @Override
                public void onSuccess(ServiceFilterResponse response) {
                    runOnUiThread(new Runnable() {

                        @Override
                        public void run() {
                            if (progress!=null)
                            progress.dismiss();
                        }
                    });

                    resultFuture.set(response);
                }
            });

            return resultFuture;
        }
    }

}
