package com.jonce.pcfilter;

//import com.example.GetStartedWithData.R;

/**
 * Represents an item in a ToDo list
 */
public class ToDoItem {

	/**
	 * Item text
	 */
	@com.google.gson.annotations.SerializedName("text")
	private String mText;

	/**
	 * Item Id
	 */
	@com.google.gson.annotations.SerializedName("id")
	private String mId;

	/**
	 * Indicates if the item is completed
	 */
	@com.google.gson.annotations.SerializedName("complete")
	private boolean mComplete;

	@com.google.gson.annotations.SerializedName("cpu")
	private String mCPU;

	@com.google.gson.annotations.SerializedName("gpu")
	private String mGpu;

	@com.google.gson.annotations.SerializedName("storage")
	private String mStorage;

	@com.google.gson.annotations.SerializedName("size")
	private String mSize;

	@com.google.gson.annotations.SerializedName("battery")
	private String mBattery;

	private String userid;
	/**
	 * ToDoItem constructor
	 */
	public ToDoItem() {

	}

	@Override
	public String toString() {
		return getText();
	}

	/**
	 * Initializes a new ToDoItem
	 * 
	 * @param text
	 *            The item text
	 * @param id
	 *            The item id
	 */
	public ToDoItem(String text, String id) {
		this.setText(text);
		this.setId(id);
	}

	/**
	 * Returns the item text
	 */
	public String getText() {
		return mText;
	}

	/**
	 * Sets the item text
	 * 
	 * @param text
	 *            text to set
	 */
	public final void setText(String text) {
		mText = text;
	}

	/**
	 * Returns the item id
	 */
	public String getId() {
		return mId;
	}

	/**
	 * Sets the item id
	 * 
	 * @param id
	 *            id to set
	 */
	public final void setId(String id) {
		mId = id;
	}

	/**
	 * Indicates if the item is marked as completed
	 */
	public boolean isComplete() {
		return mComplete;
	}

	/**
	 * Marks the item as completed or incompleted
	 */
	public void setComplete(boolean complete) {
		mComplete = complete;
	}

	/*PARAMETERS ADDED
	* */
	public void setmCPU(String c){
		this.mCPU = c;

	}

	public String getmCPU(){
		return this.mCPU;
	}


	public void setmGPU(String g){
		this.mGpu = g;

	}

	public String getmGPU(){
		return this.mGpu;
	}

	public void setStrorage(String s){
		this.mStorage = s;
	}

	public String getStrogae(){
		return this.mStorage;
	}

	public void setSize(String s){
		this.mSize = s;
	}

	public String getSize(){
		return this.mSize;
	}

	public void setBattery(String b){
		this.mBattery = b;
	}

	public String getBattery(){
		return this.mBattery;
	}


	public final void setUserid(String a){this.userid = a;}
	public String getUserid(){return this.userid;}
	@Override
	public boolean equals(Object o) {
		return o instanceof ToDoItem && ((ToDoItem) o).mText == mText;

	}
}
