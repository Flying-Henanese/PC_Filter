package com.jonce.pcfilter;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import com.jonce.pcfilter.adapter.ComputerAdapter;
import com.jonce.pcfilter.adapter.SoftWareAdapter;
import com.jonce.pcfilter.modal.Computer;
import com.jonce.pcfilter.modal.SoftWare;
import java.util.ArrayList;
import java.util.List;

public class ResultActivity extends AppCompatActivity
{
    private List<Computer> computerList;
    private Button returnBtn;
    private ListView computerView;
    private TextView computerTv;
    final int EXTRA = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.result_activity);

        Intent intent = this.getIntent();
        Bundle bundle = intent.getExtras();
        String selected = bundle.getString("selected");

        returnBtn = (Button) findViewById(R.id.returnBtn);
        computerTv = (TextView) findViewById(R.id.computerTv);
        computerView = (ListView) findViewById(R.id.computerLv);
        computerList = new ArrayList<Computer>();
        computerList = getInitComputer();
        computerList = selectedComputer(computerList, selected);

        if(computerList == null || computerList.size() < 1)
        {
            computerTv.setText("There is no computer to meet demand!");
        }
        else
        {
            ComputerAdapter computerAdapter = new ComputerAdapter(this, computerList);
            computerView.setAdapter(computerAdapter);
        }

        returnBtn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                finish();
            }
        });

        setupListViewListener();

    }

    private void setupListViewListener() {

        computerView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String updateItem =  computerList.get(position).getPcName();
                Log.i("MainActivity", "Clicked item " + position + ": " + updateItem);

                Intent intent = new Intent(ResultActivity.this, MyWeb.class);
                if (intent != null) {
                    // put "extras" into the bundle for access in the edit activity
                    intent.putExtra("item", updateItem);
                    if (updateItem.equals("Mac book")){
                        intent.putExtra("url", "https://www.jbhifi.com.au/computers-tablets/laptops/apple/apple-macbook-pro-13-2-5ghz/87407/");
                    }else if(updateItem.equals("Lenovo Y40")){
                        intent.putExtra("url", "http://www3.lenovo.com/au/en/laptops/lenovo/lenovo-y-series/Lenovo-Y40-80/p/88LG80Y0399");
                    }else if(updateItem.equals("iMac")){
                        intent.putExtra("url","https://www.jbhifi.com.au/computers-tablets/desktops/apple/apple-imac-21-5-2-9ghz/452744/");
                    }
                    // brings up the second activity
                    startActivityForResult(intent,EXTRA);
                }
            }
        });


    }

    public List<Computer> getInitComputer()
    {
        List<Computer> computerList = new ArrayList<Computer>();
        Computer computer = new Computer(R.drawable.yfourzero, "Lenovo Y40", 3, 4000, 1, 14.0f, 2.5f);
        computerList.add(computer);

        computer = new Computer(R.drawable.macbook, "Mac book", 6, 4500, 4, 12.0f, 3.0f);
        computerList.add(computer);

        computer = new Computer(R.drawable.imac, "iMac", 4, 3700, 2, 21.5f, 20f);
        computerList.add(computer);

        return computerList;
    }

    private List<Computer> selectedComputer(List<Computer> initComputer, String Selected)
    {
        List<Computer> computerList = new ArrayList<Computer>();
        List<SoftWare> isSelectList = getSelectPosition(Selected);

        int maxCpu = this.getMaxCpu(isSelectList);
        int maxGpu = this.getMaxGpu(isSelectList);
        int maxStg = this.getMaxStg(isSelectList);

        for (int i = 0; i < initComputer.size(); i++)
        {
            Computer computer = initComputer.get(i);
            if(computer.getPcCPU() >= maxCpu && computer.getPcGPU() >= maxGpu && computer.getPcStorage() >= maxStg)
            {
                computerList.add(computer);
            }
        }
        return computerList;
    }

    private List<SoftWare> getSelectPosition(String selected)
    {
        List<SoftWare> isSelected = new ArrayList<SoftWare>();
        String[] strSelect = selected.split(",");
        for (int i = 0; i < strSelect.length; i++)
        {
            isSelected.add(SoftWareAdapter.data.get(Integer.parseInt(strSelect[i])));
        }

        return isSelected;
    }

    private int getMaxCpu(List<SoftWare> isSelectList)
    {
        int max = 1;
        for (int i = 0; i < isSelectList.size(); i++)
        {
            if(isSelectList.get(i).getsFCPU() > max)
            {
                max = isSelectList.get(i).getsFCPU();
            }
        }
        return max;
    }

    private int getMaxGpu(List<SoftWare> isSelectList)
    {
        int max = 1;
        for (int i = 0; i < isSelectList.size(); i++)
        {
            if(isSelectList.get(i).getsFGPU() > max)
            {
                max = isSelectList.get(i).getsFGPU();
            }
        }
        return max;
    }

    private int getMaxStg(List<SoftWare> isSelectList)
    {
        int max = 1;
        for (int i = 0; i < isSelectList.size(); i++)
        {
            if(isSelectList.get(i).getsFStorage() > max)
            {
                max = isSelectList.get(i).getsFStorage();
            }
        }
        return max;
    }

}